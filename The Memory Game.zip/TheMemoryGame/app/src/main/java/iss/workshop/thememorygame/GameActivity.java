package iss.workshop.thememorygame;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameActivity extends AppCompatActivity {
    BroadcastReceiver mGameBroadcastReceiver;
    GameImageAdapter mGameImageAdapter;
    RecyclerView mRecyclerView;
    List<Photo> mGamePhotos;
    TextView mTimer;
    private static MediaPlayer mMediaPlayer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        setupGame();
        initAdapter();
        initRecyclerView();
        startTimer();
        initReceiver();
        setupReceiver();
        if(mMediaPlayer==null) {
            setupMediaPlayer();
        }


    }

    private void setupMediaPlayer() {
        mMediaPlayer = MediaPlayer.create(this,R.raw.mortal_kombat);
        mMediaPlayer.setOnPreparedListener(mp -> mMediaPlayer.start());
    }

    private void stopBGMusic() {
        mMediaPlayer.stop();
        mMediaPlayer.reset();
        mMediaPlayer.release();
        mMediaPlayer = null;

    }

    private void initReceiver() {
        mGameBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action != null) {

                    if (action.equals("update_score")) {
                        TextView tracker = findViewById(R.id.tracker);
                        int score = intent.getIntExtra("score",0);
                        tracker.setText(String.format("%s of 6 matches",score));

                    }
                    else if (action.equals("stop_intent")) {
                        stopBGMusic();
                    }
                }
            }
        };
    }

    private void setupReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("update_score");
        filter.addAction("stop_intent");
        registerReceiver(mGameBroadcastReceiver,filter);
    }

    private void setupGame(){
        SharedPreferences sharedPreferences = getSharedPreferences("chosen_pictures_album",MODE_PRIVATE);
        mGamePhotos = new ArrayList<>();
        for(int i = 1; i <= 6; i++) {
            String encodedByteArray = retrieveEncodedByteArray(sharedPreferences, i); // get string byte format of photo
            byte[] byteArray = decodeEncodedByteArray(encodedByteArray); // convert string to actual byte
            Bitmap bitmap = byteArray2Bitmap(byteArray); // convert byte to bitmap
            bitmapsIntoPhotos(bitmap, mGamePhotos, i); // store bitmap into photos x 2, return list
            shufflePhotos(mGamePhotos); //shuffle photos
            //rinse and repeat until total of 6 photos
        }
    }

    private String retrieveEncodedByteArray(SharedPreferences sharedPreferences, int i) {
        String encodedByteArray = sharedPreferences.getString(String.format("%s", i),null);
        return encodedByteArray;
    }

    private byte[] decodeEncodedByteArray(String encodedByteArray) {
        byte[] byteArray = Base64.decode(encodedByteArray, Base64.DEFAULT);
        return byteArray;
    }

    private Bitmap byteArray2Bitmap(byte[] byteArray) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        return bitmap;
    }

    private void initAdapter(){
        mGameImageAdapter = new GameImageAdapter(this);
        mGameImageAdapter.setPhotos(mGamePhotos);
    }

    private void initRecyclerView(){
        mRecyclerView = findViewById(R.id.recycler_view_game);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setAdapter(mGameImageAdapter);
    }

    private List<Photo> bitmapsIntoPhotos(Bitmap bitmap, List<Photo> photos, int imageTag) {
        Photo photo = new Photo();
        Photo photo_duplicate = new Photo();
        photo.setBitmap(bitmap);
        photo.setTag(String.valueOf(imageTag));
        photo_duplicate.setBitmap(bitmap);
        photo_duplicate.setTag(String.valueOf(imageTag));
        photos.add(photo);
        photos.add(photo_duplicate);
        return photos;
    }

    private List<Photo> shufflePhotos(List<Photo> photos) {
        Collections.shuffle(photos);  //shuffles the images so it can be displayed randomly
        return photos;
    }

    private String elapsedTime(int elapsed) {
        int hours = (int) (elapsed / 3600d);
        if(hours >= 24) {
            hours = 0;
        }
        double remainder = elapsed % 3600d;
        int minutes = (int)(remainder / 60d);
        int seconds = (int) remainder % 60;
        return String.format("%02d:%02d:%02d",hours,minutes,seconds);
    }

    private void startTimer() {

        mTimer = findViewById(R.id.timer);
        Handler handler = new Handler();
        handler.post(new Runnable(){
            int counter = 0;
            @Override
            public void run() {
                counter++;
                String time = elapsedTime(counter);
                mTimer.setText(time);

                handler.postDelayed(this,1000); //callback to continuously get increment
            }
        });

    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        unregisterReceiver(mGameBroadcastReceiver);
        mGameImageAdapter = null;
        mGamePhotos = null;
        stopBGMusic();
    }
}



