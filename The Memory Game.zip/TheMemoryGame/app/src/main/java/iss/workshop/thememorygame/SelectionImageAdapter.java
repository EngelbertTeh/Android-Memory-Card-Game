package iss.workshop.thememorygame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SelectionImageAdapter extends RecyclerView.Adapter<SelectionImageAdapter.ViewHolder>{

    private Context context;
    private List<Photo> photos;
    private int mCounter = 0;
    private List<String> selectedImgTags = new ArrayList<>();

    public SelectionImageAdapter(Context context) {
        this.context = context;
    }

    public List<Photo> getPhotos() {
        return photos;
    }
    public void setPhotos(List<Photo> photos) {
            this.photos = photos;
    }

    private String int2Expression(int i) {
        switch (i) {
            case 1:
                return "First";
            case 2:
                return "Second";
            case 3:
                return "Third";
            case 4:
                return "Fourth";
            case 5:
                return "Fifth";
            case 6:
                return "Sixth and Final";
            default:
                return "No";
        }
    }

    @NonNull
    @Override
    public SelectionImageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View photoTemplate = LayoutInflater.from(context).inflate(R.layout.template_photo,parent,false);
        photoTemplate.setOnClickListener(view -> {


            TextView tagTextView = view.findViewById(R.id.img_tag);
            String tag = tagTextView.getText().toString();
            Log.d("mytag",tag);

            if(!selectedImgTags.contains(tag)) {
            mCounter++;
                Log.d("counter",String.valueOf(mCounter));
            showUIEffects(view);
            ImageView photo = view.findViewById(R.id.photo_);
            Bitmap bitmap = img2Bitmap(photo);
            byte[] byteArray = bitmap2ByteArray(bitmap);
                if (byteArray!=null) {
                    storeChosen(byteArray, String.valueOf(mCounter)); // store image in shared preferences
                }
                selectedImgTags.add( String.valueOf(mCounter));
                tagTextView.setText(String.valueOf(mCounter)); // storing the counter as a tag, to prevent same image from being selected
            }

            if(mCounter==6) {
                mCounter = 0;
                photos.clear();
                selectedImgTags.clear();
                letTheGamesBegin();
            }
        });
        return new ViewHolder(photoTemplate);
    }

    @Override
    public void onBindViewHolder(@NonNull SelectionImageAdapter.ViewHolder holder, int position) {

            holder.photoLayout.setTag(position);
            holder.photoLayout.setImageBitmap(photos.get(position).getBitmap());
            holder.imageTag.setText(photos.get(position).getTag());
    }

    @Override
    public int getItemCount() {

        if(photos.size()>20) {  // validation to prevent possibility of system passing in > 20 images due to some glitch, because we only need 20
            return 20;
        }else return photos.size();
    }

    private Bitmap img2Bitmap(ImageView photo) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) photo.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();
        return bitmap;
    }

    private byte[] bitmap2ByteArray(Bitmap bitmap) {
        try {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            stream.close();
            return stream.toByteArray();
        } catch (Exception e) {
            Log.e("ERR_bit2byte",String.valueOf(e));
            return null;
        }
    }

    private void storeChosen(byte[] byteArray, String tag) { //stores images in SP
        SharedPreferences sharedPreferences = context.getSharedPreferences("chosen_pictures_album", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(tag, Base64.encodeToString(byteArray, Base64.DEFAULT)); // tags each image with a number
        editor.commit();
    }

    private void showUIEffects(View view) {
        view.setElevation(10f);
        view.setBackgroundColor(Color.parseColor("#916E99"));
        String expression = int2Expression(mCounter);
        Intent intent = new Intent();
        intent.setAction("update_pick_count");
        intent.putExtra("pick_count",String.format("%s pick!",expression));
        context.sendBroadcast(intent);
    }

    private void letTheGamesBegin() {
       Intent intent = new Intent();
       intent.setAction("start_game");
        context.sendBroadcast(intent);
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView photoLayout;
        private TextView imageTag;

        public ViewHolder(@NonNull View photoTemplateLayout) {
            super(photoTemplateLayout);
            photoLayout = photoTemplateLayout.findViewById(R.id.photo_);
            imageTag = photoTemplateLayout.findViewById((R.id.img_tag));
        }
    }
}
