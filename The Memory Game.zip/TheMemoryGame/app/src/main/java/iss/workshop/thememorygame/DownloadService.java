package iss.workshop.thememorygame;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.IBinder;
import android.util.Log;

import org.jetbrains.annotations.NotNull;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class DownloadService extends Service {

    private Thread bkgThread;
    private boolean inTransaction = false;

    @Override
    public void onCreate(){
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int viewId) {
        if (intent != null) {
            String action = intent.getAction();
            if (action != null) {
                if (action == "download_img") {
                    String url = intent.getStringExtra("url");
                    if (inTransaction == false) {
                        downloadImages(url);
                    }
                } else if (action == "stop_thread") {
                    if (bkgThread != null) {
                        bkgThread.interrupt();
                        inTransaction = false;
                    }
                }
            }
        }
            return START_STICKY;
        }

    private void downloadImages(String mainURL) {

        inTransaction = true;
            bkgThread = new Thread(() -> {
                try {
                    List<String> imgURLs = extractImgURLs(mainURL); // will return list with 20 urls or null
                    if (imgURLs != null) {
                        for (int i = 0; i < imgURLs.size(); i++) {
                            Bitmap bitmap = downloadBitmap(imgURLs.get(i));
                            ByteArrayOutputStream stream = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                            byte[] byteArray = stream.toByteArray();
                            callBack("image_ready", byteArray);
                            stream.close();
                            inTransaction = false;
                        }
                    }
                } catch (  IndexOutOfBoundsException | NullPointerException  e) {
                    Log.e("problem_downloading", String.valueOf(e));
                    callBack("too_fast");

                } catch(InterruptedIOException  e) {
                    Log.e("problem_downloading", String.valueOf(e));
                    callBack("too_fast");
                }
                catch (IOException e) {
                    Log.e("problem_downloading", String.valueOf(e));
                    callBack("got_problem");
                } catch(Exception e) {
                    Log.e("problem_downloading", String.valueOf(e));
                }
            });  bkgThread.start();
    }

    private List<String> extractImgURLs(String mainURL) throws IOException {
        List<String> imgURLs = new ArrayList<String>();

        Document doc = Jsoup.connect(mainURL).get();
        Elements elements = doc.select("img");
        int i = -1;

        try {
            while (imgURLs.size() < 20) {
                i++;
                Element element = elements.get(i);
                String absolutePath = element.attr("src");

                if (!absolutePath.contains(".svg")) {
                    if (absolutePath.contains("https")) {
                        imgURLs.add(absolutePath);
                    }
                } else continue;
            }

                return imgURLs;

        } catch (Exception e) {
            callBack("got_problem"); // if I couldn't get 20 url images from crawling a page, I'll tell user to change url, and rethrow exception
            throw e;
        }
    }

    private Bitmap downloadBitmap(String imgURL) throws Exception{

            URL url = new URL(imgURL);
            URLConnection conn = url.openConnection();
            InputStream is = conn.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            is.close();
            return bitmap;
    }

    private void callBack(String message, byte[] byteArray) {
        Intent intent = new Intent();
        intent.setAction(message);
        intent.putExtra("byteArray", byteArray);
        sendBroadcast(intent);
    }

    private void callBack(String message) {
        Intent intent = new Intent();
        intent.setAction(message);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if (bkgThread!=null) {
            bkgThread.interrupt();
            inTransaction = false;
        }
    }

    @NotNull
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
