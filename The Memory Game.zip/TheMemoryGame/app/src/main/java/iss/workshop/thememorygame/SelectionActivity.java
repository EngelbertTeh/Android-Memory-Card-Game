package iss.workshop.thememorygame;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class SelectionActivity extends AppCompatActivity {
    BroadcastReceiver dllBroadcastReceiver;
    SelectionImageAdapter mSelectionImageAdapter;
    RecyclerView mRecyclerView;
    EditText mURLEditTxt;
    Button mFetchBtn;
    LinearLayout mProgressViewGroup;
    ProgressBar mProgressBar;
    TextView mPBarTxtView;
    boolean hasClicked;
    boolean toasted;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);


        initReceiver();
        setupReceiver();
        setupUIControls();
        initListeners();
        initAdapter();
        initRecyclerView();
    }

    private void initAdapter(){
        List<Photo> photos = new ArrayList<>();
        mSelectionImageAdapter = new SelectionImageAdapter(this);
        mSelectionImageAdapter.setPhotos(photos);
    }
    private void initRecyclerView(){
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setAdapter(mSelectionImageAdapter);
    }

    private void initReceiver() {
        dllBroadcastReceiver = new BroadcastReceiver(){
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                    if(action!=null) {
                        if(action.equals("image_ready")){
                            byte[] byteArray = intent.getByteArrayExtra("byteArray");
                            Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                            bindImg2Adapter(bitmap);
                            displayImage();
                            showDllProgress();
                            boolean isFinishedAllDll = updateProgress();
                            if(isFinishedAllDll) {
                                hideDllProgress();
                            }
                        }
                        else if (action.equals("start_game")) {
                            Intent startIntent = new Intent(SelectionActivity.this,GameActivity.class);
                            startActivity(startIntent);
                        }
                        else if (action.equals("update_pick_count"))
                        {
                            TextView pickCountTV = findViewById(R.id.pick_count);
                            pickCountTV.setVisibility(View.VISIBLE);
                            pickCountTV.setText(intent.getStringExtra("pick_count"));
                        }
                        else if(action.equals("got_problem") && !toasted){
                            toasted = true;
                            Toast.makeText(getApplicationContext(),"Please try again, probably with a new URL",Toast.LENGTH_SHORT).show();
                            unToast();
                        }
                        else if(action.equals("too_fast") && !toasted){
                            toasted = true;
                            Toast.makeText(getApplicationContext(),"Woah slow down cowboy. . ",Toast.LENGTH_SHORT).show();
                            unToast();
                        }
                }


            }
        };
    }

    private void setupReceiver(){
        IntentFilter filter = new IntentFilter();
        filter.addAction("image_ready");
        filter.addAction("got_problem");
        filter.addAction("too_fast");
        filter.addAction("start_game");
        filter.addAction("update_pick_count");
        registerReceiver(dllBroadcastReceiver,filter);
    }

    private void setupUIControls() {
        mURLEditTxt = findViewById(R.id.url_edit_txt);
        mFetchBtn = findViewById(R.id.fetch_btn);
        mProgressViewGroup = findViewById(R.id.btm_ctrl);
        mProgressBar = findViewById(R.id.progress_bar);
        mPBarTxtView = findViewById(R.id.pbtext_view);
    }

    private void initListeners(){
        mFetchBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(hasClicked) return;
                String url = mURLEditTxt.getText().toString();
                hasClicked = true;
                reset();
                startFetchImgSvc(url);
            }
        });
    }

    private void startFetchImgSvc(String mainURL) {
        Intent intent = new Intent(getApplicationContext(),DownloadService.class);
        intent.setAction("download_img");
        intent.putExtra("url",mainURL);
        startService(intent);
    }

    private void bindImg2Adapter(Bitmap bitmap){
        List<Photo> photos = mSelectionImageAdapter.getPhotos();
        Photo photo = new Photo();
        photo.setBitmap(bitmap);
        photos.add(photo);
        mSelectionImageAdapter.setPhotos(photos);
    }

    private void displayImage() {
        mRecyclerView.setAdapter(mSelectionImageAdapter);
    }

    private void showDllProgress() {
        mProgressViewGroup.setVisibility(View.VISIBLE);
    }

    private void hideDllProgress() {
        mProgressViewGroup.setVisibility(View.GONE);
    }

    private boolean updateProgress() {
        int currentPercent = mProgressBar.getProgress();
        double fraction = currentPercent/100d;
        int currentImageCount = (int) (20 * fraction);
        int percentPerImage = 5;
        currentPercent+=percentPerImage;
        mProgressBar.setProgress(currentPercent);
        mPBarTxtView.setText(String.format("Downloading %d out of 20 images", currentImageCount+ 1));
        Log.d("percent",String.valueOf(currentPercent));
        return currentPercent >= 100;
    }

    private synchronized  void reset() {
        stopServiceThread();

        int progress = mProgressBar.getProgress();
        List<Photo> photos = mSelectionImageAdapter.getPhotos();

        if(progress==mProgressBar.getProgress() && photos.equals(mSelectionImageAdapter.getPhotos())) {
            mProgressBar.setProgress(0);
            Log.d("progress1",String.valueOf(progress));
            if(photos.equals(mSelectionImageAdapter.getPhotos())){
                mSelectionImageAdapter.setPhotos(new ArrayList<>());
                mPBarTxtView.setText(String.format("Downloading %d out of 20 images", 0));
                hasClicked = false;
                Log.d("progress2",String.valueOf(progress));
            }
            else {
                mProgressBar.setProgress(progress);
                hasClicked = false;
                return;
            }
        }
        else {
            hasClicked = false;
            return;
        }

    }

    private void stopServiceThread() {
        Intent intent = new Intent(getApplicationContext(),DownloadService.class);
        intent.setAction("stop_thread");
        startService(intent);
    }

    private void unToast() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable(){
           @Override
           public void run(){
               toasted = false;
           }
        },2000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(dllBroadcastReceiver);
        mSelectionImageAdapter = null;
    }
}


