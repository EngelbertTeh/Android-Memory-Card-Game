package iss.workshop.thememorygame;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class GameImageAdapter extends RecyclerView.Adapter<GameImageAdapter.ViewHolder>{

    private final Context context;
    private List<Photo> photos;
    private List<View> mPlaceHolder;
    private int mMatchCounter;
    private  ObjectAnimator animator;
    View mPhotoTemplate;


    public GameImageAdapter(Context context) {
        this.context = context;
        mPlaceHolder = new ArrayList<>();
        mMatchCounter = 0;
    }

    public void setPhotos(List<Photo> photos) {
            this.photos = photos;
    }

    @NonNull
    @Override
    public GameImageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View photoTemplate = LayoutInflater.from(context).inflate(R.layout.template_photo,parent,false);
        mPhotoTemplate = photoTemplate;
        photoTemplate.setOnClickListener(view -> {

            TextView isFaceUpTxtView = view.findViewById(R.id.is_face_up);
            if(isFaceUpTxtView.getText().toString().equals("false")) {  // check to see whether the card is already flipped
                if(mPlaceHolder.size()<2){
                    mPlaceHolder.add(view); // if not flipped add to place holder
                    isFaceUpTxtView.setText("true"); // change status of card to flipped face up
                }
                    flipView(view,false); // flip card visually

                new Handler().post(()->{

                if(mPlaceHolder.size()==2)  {

                    List<View> localPlaceHolder = new ArrayList<>();
                    localPlaceHolder.addAll(mPlaceHolder);

                    emptyList(mPlaceHolder); // clear placeholder list, to free it up so that it be used again

                    boolean isSame = compareImages(localPlaceHolder);  // if both cards facing up, to compare their image tag string value
                    if (!isSame) {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                                if(localPlaceHolder.size()==2){
                                    flipBothPhotos(localPlaceHolder); //if not same flip them face down
                                }

                            }
                        }, 1000);


                    } else {  // send broadcast to update score if matches
                        mMatchCounter++;
                        Intent broadcastIntent = new Intent();
                        broadcastIntent.setAction("update_score");
                        broadcastIntent.putExtra("score", mMatchCounter);
                        context.sendBroadcast(broadcastIntent);

                        // >=)
                            new Handler().postDelayed(()->{ // make game harder, making cards flip back downwards if player still haven't win


                                mMatchCounter--;
                                TextView is_face_up_tv1 = localPlaceHolder.get(0).findViewById(R.id.is_face_up);
                                TextView is_face_up_tv12  = localPlaceHolder.get(1).findViewById(R.id.is_face_up);
                                is_face_up_tv1.setText("false");
                                is_face_up_tv12.setText("false");
                                flipView(localPlaceHolder.get(0),true);
                                flipView(localPlaceHolder.get(1),true);
                                Intent unoReverseIntent = new Intent();
                                unoReverseIntent.setAction("update_score");
                                unoReverseIntent.putExtra("score", mMatchCounter);
                                context.sendBroadcast(unoReverseIntent);
                            },10000);




                        if (mMatchCounter == 6) {  //end the game when all matches
                            Intent intent = new Intent(context, SelectionActivity.class);
                            Intent stopIntent = new Intent();

                            new Handler().post( () -> {
                                stopIntent.setAction("stop_bgm");
                                context.sendBroadcast(stopIntent);
                            });

                            context.startActivity(intent);
                        }
                    }
                }
                } );


                }
            });
        return new ViewHolder(photoTemplate);


    }

    private  void flipBothPhotos(List<View> placeHolder) {
        TextView isFaceUpTxtView1 = placeHolder.get(0).findViewById(R.id.is_face_up);
        TextView isFaceUpTxtView2 = placeHolder.get(1).findViewById(R.id.is_face_up);
        isFaceUpTxtView1.setText("false");
        isFaceUpTxtView2.setText("false");

        flipView(placeHolder.get(0),true);
        flipView(placeHolder.get(1),true);
    }

    private void emptyList(List<View> mPlaceHolder) {
        mPlaceHolder.clear();
    }



    private  void flipView(View view, boolean isFront)  {
        TextView tagIdTV = view.findViewById(R.id.img_tag);
        String tagIdStr = tagIdTV.getText().toString();

        if (isFront) {
            animator = ObjectAnimator.ofFloat(view, "rotationY", 0f, 180f);
            Glide.with(context)
                    .load(R.drawable.card_bg) // the default card back image
                    .into((ImageView)view.findViewById(R.id.photo_));
        } else {
            animator = ObjectAnimator.ofFloat(view, "rotationY", 180f, 360f);
            Glide.with( view.getContext()).clear(view);
            Photo photo = photos.stream().filter(x->x.getTag().equals(tagIdStr)).findFirst().orElse(null);
            Glide.with(context)
                    .load(photo.getBitmap())
                    .into((ImageView)view.findViewById(R.id.photo_));

        }

        animator.setDuration(200);
        animator.start();

    }

    private boolean compareImages(List<View> placeHolder) {
        TextView textView1 = placeHolder.get(0).findViewById(R.id.img_tag);
        TextView textView2 = placeHolder.get(1).findViewById(R.id.img_tag);
        String imageTag1 = textView1.getText().toString();
        String imageTag2 = textView2.getText().toString();
        return imageTag1.equals(imageTag2); // compare the two image tags, similar tags means same photo
    }

    @Override
    public void onBindViewHolder(@NonNull GameImageAdapter.ViewHolder holder, int position) {

            holder.photoLayout.setImageBitmap(photos.get(position).getBitmap());
            holder.imageTag.setText(photos.get(position).getTag());
    }


    @Override
    public int getItemCount() {
        return photos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private ImageView photoLayout;
        private TextView imageTag;
        public ViewHolder(@NonNull View photoTemplateLayout) {
            super(photoTemplateLayout);
            photoLayout = photoTemplateLayout.findViewById(R.id.photo_);
            imageTag = photoTemplateLayout.findViewById((R.id.img_tag));

            Glide.with( photoTemplateLayout.getContext())
                    .load(R.drawable.card_bg) // the default card back image
                    .into(photoLayout);
        }

    }
}
