package iss.workshop.thememorygame;

import android.graphics.Bitmap;

public class Photo {

    private Bitmap bitmap;
    private String tag;

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

}
